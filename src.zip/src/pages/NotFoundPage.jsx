import React from 'react'
import { Typography } from '@mui/material'

const NotFoundPage = () => {
  return <Typography variant="h4">Страница не найдена (404)</Typography>
}

export default NotFoundPage
